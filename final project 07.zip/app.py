import os
import json
import sqlite3
import hashlib
import re
import html
from io import BytesIO
from datetime import datetime

import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from groq import Groq
from pypdf import PdfReader

from reportlab.lib.pagesizes import A4
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.enums import TA_CENTER

from streamlit_mic_recorder import speech_to_text


# ============================================================
# CONFIGURATION
# ============================================================

load_dotenv()

API_KEY = os.getenv("GROQ_API_KEY")
MODEL = os.getenv(
    "GROQ_MODEL",
    "llama-3.3-70b-versatile"
)

DB = "interviews.db"

MAX_QUESTIONS = 8


# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="AI Interview Agent Pro",
    page_icon="🎯",
    layout="wide",
)


# ============================================================
# CHECK API KEY
# ============================================================

if not API_KEY:

    st.error(
        """
        ❌ GROQ_API_KEY is missing.

        Create a .env file in the same folder as app.py:

        GROQ_API_KEY=your_groq_api_key_here
        """
    )

    st.stop()


# ============================================================
# GROQ CLIENT
# ============================================================

try:

    ai = Groq(
        api_key=API_KEY
    )

except Exception as e:

    st.error(
        f"❌ Groq client error: {e}"
    )

    st.stop()


# ============================================================
# PASSWORD HASH
# ============================================================

def hash_password(password):

    return hashlib.sha256(
        password.encode("utf-8")
    ).hexdigest()


# ============================================================
# DATABASE CONNECTION
# ============================================================

def get_connection():

    return sqlite3.connect(
        DB,
        check_same_thread=False
    )


# ============================================================
# DATABASE INITIALIZATION + MIGRATION
# ============================================================

def initialize_database():

    connection = get_connection()
    cursor = connection.cursor()

    # --------------------------------------------------------
    # USERS
    # --------------------------------------------------------

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users(
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
        """
    )

    # --------------------------------------------------------
    # INTERVIEWS
    # --------------------------------------------------------

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS interviews(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            name TEXT,
            target_job TEXT,
            overall REAL,
            technical REAL,
            communication REAL,
            problem REAL,
            relevance REAL,
            recommendation TEXT,
            created TEXT,
            data TEXT
        )
        """
    )

    # --------------------------------------------------------
    # IMPORTANT:
    # MIGRATE OLD DATABASE
    # --------------------------------------------------------

    columns = cursor.execute(
        "PRAGMA table_info(interviews)"
    ).fetchall()

    existing_columns = {
        row[1]
        for row in columns
    }

    required_columns = {

        "username": "TEXT",

        "name": "TEXT",

        "target_job": "TEXT",

        "overall": "REAL",

        "technical": "REAL",

        "communication": "REAL",

        "problem": "REAL",

        "relevance": "REAL",

        "recommendation": "TEXT",

        "created": "TEXT",

        "data": "TEXT",
    }

    for column, data_type in required_columns.items():

        if column not in existing_columns:

            try:

                cursor.execute(
                    f"""
                    ALTER TABLE interviews
                    ADD COLUMN {column} {data_type}
                    """
                )

            except sqlite3.OperationalError:

                pass

    # --------------------------------------------------------
    # DEMO CANDIDATE
    # --------------------------------------------------------

    cursor.execute(
        """
        INSERT OR IGNORE INTO users
        (username, password, role)
        VALUES (?, ?, ?)
        """,
        (
            "candidate",
            hash_password("candidate123"),
            "candidate",
        ),
    )

    # --------------------------------------------------------
    # DEMO ADMIN
    # --------------------------------------------------------

    cursor.execute(
        """
        INSERT OR IGNORE INTO users
        (username, password, role)
        VALUES (?, ?, ?)
        """,
        (
            "admin",
            hash_password("admin123"),
            "admin",
        ),
    )

    connection.commit()
    connection.close()


initialize_database()


# ============================================================
# SESSION STATE
# ============================================================

DEFAULTS = {

    "login": False,

    "username": "",

    "role": "",

    "started": False,

    "finished": False,

    "profile": {},

    "resume": "",

    "job": "",

    "question": "",

    "questions": [],

    "answers": [],

    "scores": [],

    "technical": [],

    "communication": [],

    "problem": [],

    "relevance": [],

    "feedback": [],

    "evaluations": [],

    "last_evaluation": None,

    "report": None,

    "saved": False,
}


for key, value in DEFAULTS.items():

    if key not in st.session_state:

        st.session_state[key] = value


# ============================================================
# CSS
# ============================================================

st.markdown(
    """
    <style>

    .main-title {
        font-size: 42px;
        font-weight: 800;
    }

    .question-box {
        background-color: #172033;
        border-left: 6px solid #4c78ff;
        border-radius: 15px;
        padding: 25px;
        margin: 20px 0;
    }

    .question-text {
        color: white !important;
        font-size: 23px;
        font-weight: 700;
        line-height: 1.6;
    }

    .info-box {
        padding: 15px;
        border-radius: 10px;
    }

    </style>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# AI FUNCTION
# ============================================================

def ask_ai(prompt):

    try:

        response = ai.chat.completions.create(

            model=MODEL,

            messages=[

                {
                    "role": "system",
                    "content": """
You are a professional adaptive AI job interviewer.

Rules:

- Ask job-specific questions.
- Be professional and fair.
- Never reveal internal reasoning.
- Never repeat a previous question.
- Never closely rephrase a previous question.
- Use the candidate profile.
- Use the resume when useful.
- Use the job description when useful.
- Adapt difficulty according to the candidate's performance.
- Keep questions clear.
"""
                },

                {
                    "role": "user",
                    "content": prompt
                }

            ],

            temperature=0.3,
        )

        return (
            response
            .choices[0]
            .message
            .content
            .strip()
        )

    except Exception as e:

        return "ERROR: " + str(e)


# ============================================================
# JSON PARSER
# ============================================================

def parse_json(text, default):

    try:

        if not text:
            return default

        text = text.strip()

        text = text.replace(
            "```json",
            ""
        )

        text = text.replace(
            "```",
            ""
        )

        start = text.find("{")
        end = text.rfind("}")

        if start == -1 or end == -1:

            return default

        json_text = text[
            start:end + 1
        ]

        result = json.loads(
            json_text
        )

        if isinstance(result, dict):

            return result

        return default

    except Exception:

        return default


# ============================================================
# PDF RESUME READER
# ============================================================

def extract_resume_text(uploaded_file):

    if uploaded_file is None:

        return ""

    try:

        reader = PdfReader(
            uploaded_file
        )

        text = ""

        for page in reader.pages:

            page_text = (
                page.extract_text()
            )

            if page_text:

                text += (
                    page_text
                    + "\n"
                )

        return text[:18000]

    except Exception as e:

        return ""


# ============================================================
# FALLBACK QUESTIONS
# ============================================================

def get_fallback_questions():

    job = st.session_state.profile.get(
        "target_job",
        "this position"
    )

    return [

        f"Why are you interested in the {job} role?",

        "What technical skill is most important for this position and why?",

        "Describe a project you completed and explain your contribution.",

        "Describe a difficult problem you solved and how you solved it.",

        "How would you handle a task with a very tight deadline?",

        "Tell me about a time when you had to learn a new technology quickly.",

        "What technical skill are you currently improving?",

        "Why should we hire you for this position?",
    ]


# ============================================================
# GENERATE NEXT QUESTION
# ============================================================

def generate_next_question():

    profile = st.session_state.profile

    previous_questions = "\n".join(
        f"- {question}"
        for question in st.session_state.questions
    )

    history = ""

    for i in range(
        len(st.session_state.answers)
    ):

        history += f"""
Question:
{st.session_state.questions[i]}

Candidate Answer:
{st.session_state.answers[i]}

Score:
{st.session_state.scores[i]}/10

"""

    # --------------------------------------------------------
    # Difficulty
    # --------------------------------------------------------

    if not st.session_state.scores:

        difficulty = """
Start with a moderate difficulty question.
"""

    else:

        last_score = (
            st.session_state.scores[-1]
        )

        if last_score >= 8:

            difficulty = """
The candidate performed very well.
Increase the difficulty.
Ask a deeper technical, scenario or problem-solving question.
"""

        elif last_score >= 5:

            difficulty = """
The candidate performed reasonably.
Keep approximately the same difficulty.
"""

        else:

            difficulty = """
The candidate struggled.
Ask an easier fundamental question.
"""


    prompt = f"""
Candidate Profile:

{json.dumps(profile, indent=2)}


Resume:

{st.session_state.resume[:10000]}


Job Description:

{st.session_state.job[:7000]}


Previous Questions:

{previous_questions}


Interview History:

{history}


{difficulty}


Generate exactly ONE NEW interview question.

Requirements:

1. It must be relevant to the target job.
2. It must not repeat a previous question.
3. It must not closely rephrase a previous question.
4. Use resume information when useful.
5. Use job description when useful.
6. Mix technical, behavioral, practical and scenario questions.
7. Return ONLY the question.
"""

    result = ask_ai(
        prompt
    )

    result = result.strip()

    # Remove common prefixes
    result = re.sub(
        r"^(question\s*\d*\s*:\s*)",
        "",
        result,
        flags=re.IGNORECASE
    ).strip()

    existing = [
        q.lower().strip()
        for q in st.session_state.questions
    ]

    # --------------------------------------------------------
    # Validate AI result
    # --------------------------------------------------------

    invalid = False

    if not result:

        invalid = True

    if result.startswith(
        "ERROR:"
    ):

        invalid = True

    if result.lower() in existing:

        invalid = True

    # --------------------------------------------------------
    # Fallback
    # --------------------------------------------------------

    if invalid:

        result = ""

        for fallback in get_fallback_questions():

            if fallback.lower() not in existing:

                result = fallback

                break

    # Final fallback
    if not result:

        result = (
            "Tell me about your strongest "
            "technical skill and explain how "
            "you have used it in a real project."
        )

    return result


# ============================================================
# EVALUATE ANSWER
# ============================================================

def evaluate_answer(
    question,
    answer
):

    default = {

        "score": 5.0,

        "technical": 5.0,

        "communication": 5.0,

        "problem": 5.0,

        "relevance": 5.0,

        "feedback":
            "Good attempt. Add more specific details.",

        "strength":
            "The candidate attempted the question.",

        "weakness":
            "The answer could contain more specific examples.",
    }


    prompt = f"""
Evaluate this job interview answer.

Target Job:

{st.session_state.profile.get(
    "target_job",
    ""
)}


Question:

{question}


Candidate Answer:

{answer}


Scoring:

0 = Very poor
5 = Average
10 = Excellent


Evaluate:

- Overall score
- Technical knowledge
- Communication
- Problem solving
- Relevance


Return ONLY valid JSON:

{{
    "score": 0,
    "technical": 0,
    "communication": 0,
    "problem": 0,
    "relevance": 0,
    "feedback": "short useful feedback",
    "strength": "main strength",
    "weakness": "main weakness"
}}

All numeric scores MUST be between 0 and 10.
"""

    result = ask_ai(
        prompt
    )

    evaluation = parse_json(
        result,
        default
    )

    score_fields = [
        "score",
        "technical",
        "communication",
        "problem",
        "relevance",
    ]

    for field in score_fields:

        try:

            value = float(
                evaluation.get(
                    field,
                    5
                )
            )

            value = max(
                0,
                min(
                    10,
                    value
                )
            )

            evaluation[field] = round(
                value,
                1
            )

        except Exception:

            evaluation[field] = 5.0

    return evaluation


# ============================================================
# FINAL REPORT
# ============================================================

def generate_final_report():

    if not st.session_state.scores:

        return {}

    overall = round(
        sum(
            st.session_state.scores
        )
        /
        len(
            st.session_state.scores
        ),
        1
    )

    technical = round(
        sum(
            st.session_state.technical
        )
        /
        len(
            st.session_state.technical
        ),
        1
    )

    communication = round(
        sum(
            st.session_state.communication
        )
        /
        len(
            st.session_state.communication
        ),
        1
    )

    problem = round(
        sum(
            st.session_state.problem
        )
        /
        len(
            st.session_state.problem
        ),
        1
    )

    relevance = round(
        sum(
            st.session_state.relevance
        )
        /
        len(
            st.session_state.relevance
        ),
        1
    )


    if overall >= 8.5:

        recommendation = "Strong Hire"

    elif overall >= 7:

        recommendation = "Hire"

    elif overall >= 5:

        recommendation = "Consider"

    else:

        recommendation = "No Hire"


    interview_results = []

    for i in range(
        len(st.session_state.answers)
    ):

        interview_results.append({

            "question":
                st.session_state.questions[i],

            "answer":
                st.session_state.answers[i],

            "score":
                st.session_state.scores[i],

            "technical":
                st.session_state.technical[i],

            "communication":
                st.session_state.communication[i],

            "problem":
                st.session_state.problem[i],

            "relevance":
                st.session_state.relevance[i],
        })


    default_report = {

        "overall_score": overall,

        "technical_score": technical,

        "communication_score": communication,

        "problem_score": problem,

        "relevance_score": relevance,

        "technical_skills":
            "Technical performance was evaluated from the candidate's interview responses.",

        "communication":
            "Communication performance was evaluated from the candidate's responses.",

        "strengths": [
            "Completed the interview successfully.",
            "Demonstrated knowledge relevant to the target role.",
        ],

        "weaknesses": [
            "Some answers could contain more specific examples.",
            "Additional interview practice may improve performance.",
        ],

        "learning_topics": [
            "Technical interview practice",
            "Communication skills",
            "Problem solving",
        ],

        "hiring_recommendation":
            recommendation,

        "summary":
            "The candidate completed the adaptive AI interview.",
    }


    prompt = f"""
Create a professional interview report.

Candidate:

{json.dumps(
    st.session_state.profile,
    indent=2
)}


Interview Results:

{json.dumps(
    interview_results,
    indent=2
)}


Calculated Scores:

Overall: {overall}/10
Technical: {technical}/10
Communication: {communication}/10
Problem Solving: {problem}/10
Relevance: {relevance}/10


Return ONLY valid JSON:

{{
    "overall_score": {overall},
    "technical_score": {technical},
    "communication_score": {communication},
    "problem_score": {problem},
    "relevance_score": {relevance},

    "technical_skills": "professional assessment",

    "communication": "professional assessment",

    "strengths": [
        "strength 1",
        "strength 2",
        "strength 3"
    ],

    "weaknesses": [
        "weakness 1",
        "weakness 2"
    ],

    "learning_topics": [
        "topic 1",
        "topic 2",
        "topic 3"
    ],

    "hiring_recommendation": "{recommendation}",

    "summary": "professional candidate summary"
}}

Hiring recommendation MUST be one of:

Strong Hire
Hire
Consider
No Hire
"""

    result = ask_ai(
        prompt
    )

    report = parse_json(
        result,
        default_report
    )

    # Always use our calculated scores
    report["overall_score"] = overall
    report["technical_score"] = technical
    report["communication_score"] = communication
    report["problem_score"] = problem
    report["relevance_score"] = relevance

    if report.get(
        "hiring_recommendation"
    ) not in [
        "Strong Hire",
        "Hire",
        "Consider",
        "No Hire",
    ]:

        report[
            "hiring_recommendation"
        ] = recommendation

    return report


# ============================================================
# SAVE INTERVIEW
# ============================================================

def save_interview():

    if st.session_state.saved:

        return

    report = st.session_state.report

    if not report:

        return

    technical_avg = (
        sum(
            st.session_state.technical
        )
        /
        len(
            st.session_state.technical
        )
        if st.session_state.technical
        else 0
    )

    communication_avg = (
        sum(
            st.session_state.communication
        )
        /
        len(
            st.session_state.communication
        )
        if st.session_state.communication
        else 0
    )

    problem_avg = (
        sum(
            st.session_state.problem
        )
        /
        len(
            st.session_state.problem
        )
        if st.session_state.problem
        else 0
    )

    relevance_avg = (
        sum(
            st.session_state.relevance
        )
        /
        len(
            st.session_state.relevance
        )
        if st.session_state.relevance
        else 0
    )


    complete_data = {

        "profile":
            st.session_state.profile,

        "resume":
            st.session_state.resume,

        "job_description":
            st.session_state.job,

        "questions":
            st.session_state.questions,

        "answers":
            st.session_state.answers,

        "scores":
            st.session_state.scores,

        "technical":
            st.session_state.technical,

        "communication":
            st.session_state.communication,

        "problem":
            st.session_state.problem,

        "relevance":
            st.session_state.relevance,

        "evaluations":
            st.session_state.evaluations,

        "report":
            report,
    }


    connection = get_connection()

    connection.execute(
        """
        INSERT INTO interviews
        (
            username,
            name,
            target_job,
            overall,
            technical,
            communication,
            problem,
            relevance,
            recommendation,
            created,
            data
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (

            st.session_state.username,

            st.session_state.profile.get(
                "name",
                ""
            ),

            st.session_state.profile.get(
                "target_job",
                ""
            ),

            report.get(
                "overall_score",
                0
            ),

            technical_avg,

            communication_avg,

            problem_avg,

            relevance_avg,

            report.get(
                "hiring_recommendation",
                "Consider"
            ),

            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),

            json.dumps(
                complete_data,
                ensure_ascii=False
            ),
        ),
    )

    connection.commit()
    connection.close()

    st.session_state.saved = True


# ============================================================
# SAFE PDF TEXT
# ============================================================

def safe_pdf_text(value):

    if value is None:

        return ""

    return html.escape(
        str(value)
    )


# ============================================================
# PDF REPORT
# ============================================================

def create_pdf(report):

    buffer = BytesIO()

    document = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()

    styles["Title"].alignment = (
        TA_CENTER
    )

    story = []

    profile = (
        st.session_state.profile
    )


    story.append(
        Paragraph(
            "AI INTERVIEW AGENT PRO",
            styles["Title"]
        )
    )

    story.append(
        Spacer(1, 8)
    )

    story.append(
        Paragraph(
            "Interview Assessment Report",
            styles["Heading2"]
        )
    )

    story.append(
        Spacer(1, 15)
    )


    # --------------------------------------------------------
    # Candidate information
    # --------------------------------------------------------

    candidate_data = [

        [
            "Candidate",
            safe_pdf_text(
                profile.get(
                    "name",
                    ""
                )
            )
        ],

        [
            "Target Job",
            safe_pdf_text(
                profile.get(
                    "target_job",
                    ""
                )
            )
        ],

        [
            "Username",
            safe_pdf_text(
                st.session_state.username
            )
        ],

        [
            "Date",
            datetime.now().strftime(
                "%Y-%m-%d %H:%M"
            )
        ],
    ]


    table = Table(
        candidate_data,
        colWidths=[
            130,
            350
        ]
    )


    table.setStyle(
        TableStyle([

            (
                "BACKGROUND",
                (0, 0),
                (0, -1),
                colors.lightgrey
            ),

            (
                "GRID",
                (0, 0),
                (-1, -1),
                0.5,
                colors.grey
            ),

            (
                "FONTNAME",
                (0, 0),
                (0, -1),
                "Helvetica-Bold"
            ),

            (
                "VALIGN",
                (0, 0),
                (-1, -1),
                "TOP"
            ),

            (
                "PADDING",
                (0, 0),
                (-1, -1),
                7
            ),

        ])
    )


    story.append(table)

    story.append(
        Spacer(1, 20)
    )


    # --------------------------------------------------------
    # Scores
    # --------------------------------------------------------

    story.append(
        Paragraph(
            f"Overall Score: "
            f"{report.get('overall_score', 0)}/10",
            styles["Heading2"]
        )
    )

    story.append(
        Paragraph(
            f"Technical Score: "
            f"{report.get('technical_score', 0)}/10",
            styles["BodyText"]
        )
    )

    story.append(
        Paragraph(
            f"Communication Score: "
            f"{report.get('communication_score', 0)}/10",
            styles["BodyText"]
        )
    )

    story.append(
        Paragraph(
            f"Problem Solving Score: "
            f"{report.get('problem_score', 0)}/10",
            styles["BodyText"]
        )
    )

    story.append(
        Paragraph(
            f"Relevance Score: "
            f"{report.get('relevance_score', 0)}/10",
            styles["BodyText"]
        )
    )


    story.append(
        Spacer(1, 15)
    )


    # --------------------------------------------------------
    # Technical
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Technical Skills",
            styles["Heading2"]
        )
    )

    story.append(
        Paragraph(
            safe_pdf_text(
                report.get(
                    "technical_skills",
                    ""
                )
            ),
            styles["BodyText"]
        )
    )


    story.append(
        Spacer(1, 10)
    )


    # --------------------------------------------------------
    # Communication
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Communication",
            styles["Heading2"]
        )
    )

    story.append(
        Paragraph(
            safe_pdf_text(
                report.get(
                    "communication",
                    ""
                )
            ),
            styles["BodyText"]
        )
    )


    story.append(
        Spacer(1, 10)
    )


    # --------------------------------------------------------
    # Strengths
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Strengths",
            styles["Heading2"]
        )
    )

    for item in report.get(
        "strengths",
        []
    ):

        story.append(
            Paragraph(
                "• "
                + safe_pdf_text(item),
                styles["BodyText"]
            )
        )


    story.append(
        Spacer(1, 10)
    )


    # --------------------------------------------------------
    # Weaknesses
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Weaknesses",
            styles["Heading2"]
        )
    )

    for item in report.get(
        "weaknesses",
        []
    ):

        story.append(
            Paragraph(
                "• "
                + safe_pdf_text(item),
                styles["BodyText"]
            )
        )


    story.append(
        Spacer(1, 10)
    )


    # --------------------------------------------------------
    # Learning Topics
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Recommended Learning Topics",
            styles["Heading2"]
        )
    )

    for item in report.get(
        "learning_topics",
        []
    ):

        story.append(
            Paragraph(
                "• "
                + safe_pdf_text(item),
                styles["BodyText"]
            )
        )


    story.append(
        Spacer(1, 10)
    )


    # --------------------------------------------------------
    # Recommendation
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Hiring Recommendation",
            styles["Heading2"]
        )
    )

    story.append(
        Paragraph(
            safe_pdf_text(
                report.get(
                    "hiring_recommendation",
                    "Consider"
                )
            ),
            styles["BodyText"]
        )
    )


    story.append(
        Spacer(1, 10)
    )


    # --------------------------------------------------------
    # Summary
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Summary",
            styles["Heading2"]
        )
    )

    story.append(
        Paragraph(
            safe_pdf_text(
                report.get(
                    "summary",
                    ""
                )
            ),
            styles["BodyText"]
        )
    )


    story.append(
        Spacer(1, 20)
    )


    # --------------------------------------------------------
    # Question Results
    # --------------------------------------------------------

    story.append(
        Paragraph(
            "Question Results",
            styles["Heading2"]
        )
    )


    for i in range(
        len(st.session_state.answers)
    ):

        story.append(
            Paragraph(
                f"Question {i + 1}",
                styles["Heading3"]
            )
        )

        story.append(
            Paragraph(
                "<b>Question:</b> "
                + safe_pdf_text(
                    st.session_state.questions[i]
                ),
                styles["BodyText"]
            )
        )

        story.append(
            Paragraph(
                "<b>Answer:</b> "
                + safe_pdf_text(
                    st.session_state.answers[i]
                ),
                styles["BodyText"]
            )
        )

        story.append(
            Paragraph(
                f"<b>Score:</b> "
                f"{st.session_state.scores[i]}/10",
                styles["BodyText"]
            )
        )

        story.append(
            Spacer(1, 8)
        )


    document.build(
        story
    )

    buffer.seek(0)

    return buffer


# ============================================================
# RESET INTERVIEW
# ============================================================

def reset_interview():

    username = (
        st.session_state.username
    )

    role = (
        st.session_state.role
    )

    for key, value in DEFAULTS.items():

        if key in [
            "username",
            "role",
        ]:

            continue

        st.session_state[key] = value

    st.session_state.username = username
    st.session_state.role = role


# ============================================================
# LOGIN PAGE
# ============================================================

if not st.session_state.login:

    st.markdown(
        '<div class="main-title">'
        '🎯 AI Interview Agent Pro'
        '</div>',
        unsafe_allow_html=True
    )

    st.write(
        "Adaptive AI-powered job interview system."
    )

    st.divider()


    register_tab, login_tab = st.tabs(
        [
            "📝 Register",
            "🔐 Login"
        ]
    )


    # ========================================================
    # REGISTER
    # ========================================================

    with register_tab:

        st.subheader(
            "Create New Account"
        )


        new_username = st.text_input(
            "Username",
            key="new_username"
        )


        new_password = st.text_input(
            "Password",
            type="password",
            key="new_password"
        )


        confirm_password = st.text_input(
            "Confirm Password",
            type="password",
            key="confirm_password"
        )


        if st.button(
            "📝 Create Account",
            type="primary",
            use_container_width=True
        ):

            username = (
                new_username.strip()
            )


            if not username:

                st.warning(
                    "Please enter a username."
                )

            elif not new_password:

                st.warning(
                    "Please enter a password."
                )

            elif len(new_password) < 6:

                st.warning(
                    "Password must be at least 6 characters."
                )

            elif new_password != confirm_password:

                st.error(
                    "Passwords do not match."
                )

            else:

                connection = (
                    get_connection()
                )

                existing = connection.execute(
                    """
                    SELECT username
                    FROM users
                    WHERE username=?
                    """,
                    (username,)
                ).fetchone()


                if existing:

                    connection.close()

                    st.error(
                        "Username already exists."
                    )

                else:

                    connection.execute(
                        """
                        INSERT INTO users
                        (
                            username,
                            password,
                            role
                        )
                        VALUES (?, ?, ?)
                        """,
                        (
                            username,
                            hash_password(
                                new_password
                            ),
                            "candidate"
                        )
                    )

                    connection.commit()
                    connection.close()

                    st.success(
                        "✅ Account created successfully!"
                    )

                    st.info(
                        "Now open the Login tab."
                    )


    # ========================================================
    # LOGIN
    # ========================================================

    with login_tab:

        st.subheader(
            "🔐 Login"
        )


        username = st.text_input(
            "Username",
            key="login_username"
        )


        password = st.text_input(
            "Password",
            type="password",
            key="login_password"
        )


        if st.button(
            "🔐 Login",
            type="primary",
            use_container_width=True
        ):

            username = (
                username.strip()
            )


            if not username:

                st.warning(
                    "Please enter username."
                )

            elif not password:

                st.warning(
                    "Please enter password."
                )

            else:

                connection = (
                    get_connection()
                )

                result = connection.execute(
                    """
                    SELECT role
                    FROM users
                    WHERE username=?
                    AND password=?
                    """,
                    (
                        username,
                        hash_password(
                            password
                        )
                    )
                ).fetchone()

                connection.close()


                if result:

                    st.session_state.login = True

                    st.session_state.username = (
                        username
                    )

                    st.session_state.role = (
                        result[0]
                    )

                    st.session_state.started = False

                    st.session_state.finished = False

                    st.rerun()

                else:

                    st.error(
                        "❌ Invalid username or password."
                    )


    st.stop()


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.title(
        "🎯 AI Interview Pro"
    )

    st.write(
        f"👤 **User:** "
        f"{st.session_state.username}"
    )

    st.write(
        f"🔑 **Role:** "
        f"{st.session_state.role}"
    )

    st.divider()


    if st.button(
        "🚪 Logout",
        use_container_width=True
    ):

        st.session_state.clear()

        st.rerun()


# ============================================================
# ADMIN DASHBOARD
# ============================================================

if (
    st.session_state.role == "admin"
    and not st.session_state.started
    and not st.session_state.finished
):

    st.title(
        "👨‍💼 Recruiter Dashboard"
    )

    st.subheader(
        "📊 Interview History"
    )


    connection = (
        get_connection()
    )


    try:

        df = pd.read_sql_query(
            """
            SELECT
                id,
                username,
                name,
                target_job,
                overall,
                technical,
                communication,
                problem,
                relevance,
                recommendation,
                created
            FROM interviews
            ORDER BY id DESC
            """,
            connection
        )

    except Exception as e:

        st.error(
            f"Database error: {e}"
        )

        df = pd.DataFrame()


    connection.close()


    if df.empty:

        st.info(
            "No interview records available yet."
        )

    else:

        col1, col2, col3 = st.columns(3)


        with col1:

            st.metric(
                "Total Interviews",
                len(df)
            )


        with col2:

            st.metric(
                "Average Score",
                f"{df['overall'].mean():.1f}/10"
            )


        with col3:

            strong_hire_count = len(
                df[
                    df["recommendation"]
                    == "Strong Hire"
                ]
            )

            st.metric(
                "Strong Hire",
                strong_hire_count
            )


        st.divider()


        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True
        )


        st.subheader(
            "📈 Candidate Scores"
        )


        chart = df[
            [
                "name",
                "overall"
            ]
        ].copy()


        chart = chart.set_index(
            "name"
        )


        st.bar_chart(
            chart
        )


    st.stop()


# ============================================================
# CANDIDATE PROFILE PAGE
# ============================================================

if (
    not st.session_state.started
    and not st.session_state.finished
):

    st.title(
        "🎯 Candidate Information"
    )

    st.write(
        "Enter your information to start the AI interview."
    )

    st.divider()


    col1, col2 = st.columns(2)


    with col1:

        name = st.text_input(
            "Full Name *",
            placeholder="Enter your full name"
        )


        education = st.text_area(
            "Education *",
            placeholder="BS Computer Science"
        )


        skills = st.text_area(
            "Skills *",
            placeholder=(
                "Python, SQL, AI, "
                "Machine Learning"
            )
        )


        experience = st.text_area(
            "Experience",
            placeholder=(
                "Fresher / Internship / Projects"
            )
        )


    with col2:

        target_job = st.text_input(
            "Target Job *",
            placeholder="AI Engineer"
        )


        resume_file = st.file_uploader(
            "📄 Upload Resume",
            type=["pdf"]
        )


        job_description = st.text_area(
            "🎯 Job Description",
            height=180,
            placeholder=(
                "Paste job description here..."
            )
        )


        st.caption(
            "Resume and job description are optional."
        )


    st.divider()


    if st.button(
        "🚀 Analyze Profile & Start Interview",
        type="primary",
        use_container_width=True
    ):

        if not name.strip():

            st.warning(
                "Please enter your name."
            )

        elif not education.strip():

            st.warning(
                "Please enter education."
            )

        elif not skills.strip():

            st.warning(
                "Please enter skills."
            )

        elif not target_job.strip():

            st.warning(
                "Please enter target job."
            )

        else:

            # ------------------------------------------------
            # Save candidate profile
            # ------------------------------------------------

            st.session_state.profile = {

                "name":
                    name.strip(),

                "education":
                    education.strip(),

                "skills":
                    skills.strip(),

                "experience":
                    experience.strip(),

                "target_job":
                    target_job.strip(),
            }


            # ------------------------------------------------
            # Resume
            # ------------------------------------------------

            with st.spinner(
                "📄 Reading resume..."
            ):

                st.session_state.resume = (
                    extract_resume_text(
                        resume_file
                    )
                )


            # ------------------------------------------------
            # Job description
            # ------------------------------------------------

            st.session_state.job = (
                job_description.strip()
            )


            # ------------------------------------------------
            # Reset interview
            # ------------------------------------------------

            st.session_state.questions = []

            st.session_state.answers = []

            st.session_state.scores = []

            st.session_state.technical = []

            st.session_state.communication = []

            st.session_state.problem = []

            st.session_state.relevance = []

            st.session_state.feedback = []

            st.session_state.evaluations = []

            st.session_state.last_evaluation = None

            st.session_state.report = None

            st.session_state.saved = False


            # ------------------------------------------------
            # FIRST QUESTION
            # ------------------------------------------------

            with st.spinner(
                "🤖 Generating your first interview question..."
            ):

                first_question = (
                    generate_next_question()
                )


            # ------------------------------------------------
            # IMPORTANT QUESTION STATE
            # ------------------------------------------------

            st.session_state.question = (
                first_question
            )

            st.session_state.questions = [
                first_question
            ]

            st.session_state.started = True

            st.session_state.finished = False


            # ------------------------------------------------
            # RERUN
            # ------------------------------------------------

            st.rerun()


    st.stop()


# ============================================================
# INTERVIEW PAGE
# ============================================================

if (
    st.session_state.started
    and not st.session_state.finished
):

    st.title(
        "🎤 AI Interview"
    )


    profile = (
        st.session_state.profile
    )


    # --------------------------------------------------------
    # Interview header
    # --------------------------------------------------------

    col1, col2, col3 = st.columns(3)


    with col1:

        st.metric(
            "Candidate",
            profile.get(
                "name",
                ""
            )
        )


    with col2:

        st.metric(
            "Target Job",
            profile.get(
                "target_job",
                ""
            )
        )


    with col3:

        question_number = (
            len(
                st.session_state.answers
            ) + 1
        )

        st.metric(
            "Question",
            f"{question_number}/{MAX_QUESTIONS}"
        )


    st.divider()


    # --------------------------------------------------------
    # Previous evaluation
    # --------------------------------------------------------

    if st.session_state.last_evaluation:

        evaluation = (
            st.session_state.last_evaluation
        )


        st.subheader(
            "📋 Previous Answer Feedback"
        )


        a, b, c, d = st.columns(4)


        with a:

            st.metric(
                "Score",
                f"{evaluation['score']}/10"
            )


        with b:

            st.metric(
                "Technical",
                f"{evaluation['technical']}/10"
            )


        with c:

            st.metric(
                "Communication",
                f"{evaluation['communication']}/10"
            )


        with d:

            st.metric(
                "Problem",
                f"{evaluation['problem']}/10"
            )


        st.info(
            evaluation.get(
                "feedback",
                ""
            )
        )


        st.write(
            "**Strength:** "
            + evaluation.get(
                "strength",
                ""
            )
        )


        st.write(
            "**Weakness:** "
            + evaluation.get(
                "weakness",
                ""
            )
        )


        st.divider()


    # --------------------------------------------------------
    # CURRENT QUESTION
    # --------------------------------------------------------

    st.subheader(
        f"Question {question_number}"
    )


    question_for_display = html.escape(
        st.session_state.question
    )


    st.markdown(
        f"""
        <div class="question-box">
            <div class="question-text">
                {question_for_display}
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )


    # ========================================================
    # ANSWER METHOD
    # ========================================================

    st.subheader(
        "✍️ Your Answer"
    )


    answer_mode = st.radio(
        "Choose answer method:",
        [
            "⌨️ Type Answer",
            "🎤 Voice Answer",
        ],
        horizontal=True,
        key=f"answer_mode_{question_number}",
    )


    answer = ""


    # ========================================================
    # TYPED ANSWER
    # ========================================================

    if answer_mode == "⌨️ Type Answer":

        answer = st.text_area(
            "Type your answer",
            height=220,
            placeholder=(
                "Write your interview answer here..."
            ),
            key=f"typed_answer_{question_number}",
        )


    # ========================================================
    # VOICE ANSWER
    # ========================================================

    else:

        st.info(
            "🎤 Click Start Recording and speak your answer."
        )


        try:

            voice_text = speech_to_text(

                language="en",

                start_prompt="🎤 Start Recording",

                stop_prompt="⏹️ Stop Recording",

                just_once=False,

                use_container_width=True,

                key=f"voice_answer_{question_number}",
            )

        except Exception as e:

            voice_text = ""

            st.error(
                f"Voice input error: {e}"
            )


        if voice_text:

            st.success(
                "✅ Voice converted to text."
            )


            st.text_area(
                "Recognized Answer",
                value=voice_text,
                height=220,
                disabled=True,
                key=f"recognized_{question_number}",
            )


            answer = voice_text


        else:

            answer = ""


    # ========================================================
    # SUBMIT ANSWER
    # ========================================================

    st.divider()


    if st.button(
        "📤 Submit Answer",
        type="primary",
        use_container_width=True,
    ):

        if not answer or not answer.strip():

            st.warning(
                "⚠️ Please type or record your answer first."
            )

        else:

            current_question = (
                st.session_state.question
            )


            # ------------------------------------------------
            # Evaluate
            # ------------------------------------------------

            with st.spinner(
                "🤖 Evaluating your answer..."
            ):

                evaluation = (
                    evaluate_answer(
                        current_question,
                        answer.strip()
                    )
                )


            # ------------------------------------------------
            # Save answer
            # ------------------------------------------------

            st.session_state.answers.append(
                answer.strip()
            )


            st.session_state.scores.append(
                evaluation["score"]
            )


            st.session_state.technical.append(
                evaluation["technical"]
            )


            st.session_state.communication.append(
                evaluation["communication"]
            )


            st.session_state.problem.append(
                evaluation["problem"]
            )


            st.session_state.relevance.append(
                evaluation["relevance"]
            )


            st.session_state.feedback.append(
                evaluation["feedback"]
            )


            st.session_state.evaluations.append(
                evaluation
            )


            st.session_state.last_evaluation = (
                evaluation
            )


            # =================================================
            # INTERVIEW FINISHED
            # =================================================

            if len(
                st.session_state.answers
            ) >= MAX_QUESTIONS:

                with st.spinner(
                    "📊 Generating final report..."
                ):

                    final_report = (
                        generate_final_report()
                    )


                st.session_state.report = (
                    final_report
                )


                st.session_state.finished = True

                st.session_state.started = False


                # Save to SQLite
                try:

                    save_interview()

                except Exception as e:

                    st.error(
                        f"Interview completed, "
                        f"but database save failed: {e}"
                    )


                st.rerun()


            # =================================================
            # NEXT QUESTION
            # =================================================

            else:

                with st.spinner(
                    "🤖 Generating next adaptive question..."
                ):

                    next_question = (
                        generate_next_question()
                    )


                st.session_state.question = (
                    next_question
                )


                st.session_state.questions.append(
                    next_question
                )


                st.rerun()


    st.stop()


# ============================================================
# FINAL REPORT PAGE
# ============================================================

if st.session_state.finished:

    st.title(
        "📊 Final Interview Report"
    )


    report = (
        st.session_state.report
    )


    if not report:

        st.error(
            "❌ Final report is not available."
        )

        st.stop()


    # --------------------------------------------------------
    # Candidate
    # --------------------------------------------------------

    st.subheader(
        f"Candidate: "
        f"{st.session_state.profile.get('name', '')}"
    )


    st.write(
        f"**Target Job:** "
        f"{st.session_state.profile.get('target_job', '')}"
    )


    st.divider()


    # --------------------------------------------------------
    # Score cards
    # --------------------------------------------------------

    c1, c2, c3, c4, c5 = st.columns(5)


    with c1:

        st.metric(
            "Overall",
            f"{report.get('overall_score', 0)}/10"
        )


    with c2:

        st.metric(
            "Technical",
            f"{report.get('technical_score', 0)}/10"
        )


    with c3:

        st.metric(
            "Communication",
            f"{report.get('communication_score', 0)}/10"
        )


    with c4:

        st.metric(
            "Problem Solving",
            f"{report.get('problem_score', 0)}/10"
        )


    with c5:

        st.metric(
            "Relevance",
            f"{report.get('relevance_score', 0)}/10"
        )


    st.divider()


    # --------------------------------------------------------
    # Recommendation
    # --------------------------------------------------------

    recommendation = report.get(
        "hiring_recommendation",
        "Consider"
    )


    st.subheader(
        "🎯 Hiring Recommendation"
    )


    if recommendation == "Strong Hire":

        st.success(
            "🟢 STRONG HIRE"
        )

    elif recommendation == "Hire":

        st.success(
            "🟢 HIRE"
        )

    elif recommendation == "Consider":

        st.warning(
            "🟡 CONSIDER"
        )

    else:

        st.error(
            "🔴 NO HIRE"
        )


    # --------------------------------------------------------
    # Summary
    # --------------------------------------------------------

    st.subheader(
        "📝 Summary"
    )

    st.write(
        report.get(
            "summary",
            ""
        )
    )


    # --------------------------------------------------------
    # Technical
    # --------------------------------------------------------

    st.subheader(
        "💻 Technical Skills"
    )

    st.write(
        report.get(
            "technical_skills",
            ""
        )
    )


    # --------------------------------------------------------
    # Communication
    # --------------------------------------------------------

    st.subheader(
        "🗣️ Communication"
    )

    st.write(
        report.get(
            "communication",
            ""
        )
    )


    # --------------------------------------------------------
    # Strengths / Weaknesses
    # --------------------------------------------------------

    left, right = st.columns(2)


    with left:

        st.subheader(
            "💪 Strengths"
        )

        for item in report.get(
            "strengths",
            []
        ):

            st.write(
                "✅ " + str(item)
            )


    with right:

        st.subheader(
            "⚠️ Weaknesses"
        )

        for item in report.get(
            "weaknesses",
            []
        ):

            st.write(
                "• " + str(item)
            )


    # --------------------------------------------------------
    # Learning topics
    # --------------------------------------------------------

    st.subheader(
        "📚 Recommended Learning Topics"
    )


    for item in report.get(
        "learning_topics",
        []
    ):

        st.write(
            "📌 " + str(item)
        )


    st.divider()


    # ========================================================
    # QUESTION RESULTS
    # ========================================================

    st.subheader(
        "📋 Question-by-Question Results"
    )


    for i in range(
        len(
            st.session_state.answers
        )
    ):

        score = (
            st.session_state.scores[i]
        )


        with st.expander(
            f"Question {i + 1} — "
            f"Score: {score}/10"
        ):

            st.write(
                "**Question:**"
            )

            st.write(
                st.session_state.questions[i]
            )


            st.write(
                "**Candidate Answer:**"
            )

            st.write(
                st.session_state.answers[i]
            )


            evaluation = (
                st.session_state.evaluations[i]
            )


            a, b, c, d, e = st.columns(5)


            with a:

                st.metric(
                    "Score",
                    f"{evaluation['score']}/10"
                )


            with b:

                st.metric(
                    "Technical",
                    f"{evaluation['technical']}/10"
                )


            with c:

                st.metric(
                    "Communication",
                    f"{evaluation['communication']}/10"
                )


            with d:

                st.metric(
                    "Problem",
                    f"{evaluation['problem']}/10"
                )


            with e:

                st.metric(
                    "Relevance",
                    f"{evaluation['relevance']}/10"
                )


            st.info(
                evaluation.get(
                    "feedback",
                    ""
                )
            )


            st.write(
                "**Strength:**",
                evaluation.get(
                    "strength",
                    ""
                )
            )


            st.write(
                "**Weakness:**",
                evaluation.get(
                    "weakness",
                    ""
                )
            )


    # ========================================================
    # PDF DOWNLOAD
    # ========================================================

    st.divider()


    st.subheader(
        "📄 Download Interview Report"
    )


    try:

        pdf = create_pdf(
            report
        )


        candidate_name = (
            st.session_state.profile
            .get(
                "name",
                "candidate"
            )
        )


        safe_name = re.sub(
            r"[^a-zA-Z0-9_-]+",
            "_",
            candidate_name
        )


        st.download_button(
            label="⬇️ Download PDF Report",
            data=pdf,
            file_name=(
                f"AI_Interview_Report_"
                f"{safe_name}.pdf"
            ),
            mime="application/pdf",
            type="primary",
            use_container_width=True,
        )

    except Exception as e:

        st.error(
            f"PDF generation error: {e}"
        )


    # ========================================================
    # NEW INTERVIEW
    # ========================================================

    st.divider()


    if st.button(
        "🔄 Start New Interview",
        type="primary",
        use_container_width=True,
    ):

        reset_interview()

        st.rerun()