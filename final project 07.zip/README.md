# AI Interview Agent Pro

AI-based personalized and adaptive job interview system.

## Features

- Candidate information
- Resume PDF upload
- Job description
- AI profile analysis
- Adaptive interview questions
- Technical scoring
- Communication scoring
- Problem-solving scoring
- Voice answer
- Automatic answer evaluation
- Performance chart
- PDF interview report
- Interview history
- Recruiter dashboard
- Candidate/Admin login
- Hiring recommendation

## Installation

Install required packages:

pip install -r requirements.txt

Add your Groq API key to .env:

GROQ_API_KEY=your_api_key

Run:

streamlit run app.py