
import os
import json
from datetime import datetime

import streamlit as st
import requests
from dotenv import load_dotenv
from langchain_groq import ChatGroq


# ============================================================
# LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY")
SENDGRID_SENDER_EMAIL = os.getenv("SENDGRID_SENDER_EMAIL")

PUSHOVER_APP_TOKEN = os.getenv("PUSHOVER_APP_TOKEN")
PUSHOVER_USER_KEY = os.getenv("PUSHOVER_USER_KEY")


# ============================================================
# APPLICATION CONFIGURATION
# ============================================================

APP_TITLE = "Intelligent Communication Assistant"

MODEL = "openai/gpt-oss-20b"


# ============================================================
# STREAMLIT CONFIGURATION
# ============================================================

st.set_page_config(
    page_title=APP_TITLE,
    page_icon="📨",
    layout="wide",
    initial_sidebar_state="expanded"
)


# ============================================================
# SESSION STATE
# ============================================================

if "logs" not in st.session_state:
    st.session_state.logs = []


# ============================================================
# SIMPLE CSS
# IMPORTANT:
# NO HERO HTML IS USED
# ============================================================

st.markdown(
    """
    <style>

    .stApp {
        background-color: #f5f7fb;
    }

    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1400px;
    }

    h1 {
        color: #111827 !important;
        font-weight: 800 !important;
    }

    h2 {
        color: #1f2937 !important;
        font-weight: 750 !important;
    }

    h3 {
        color: #374151 !important;
        font-weight: 700 !important;
    }

    p {
        color: #374151;
    }

    section[data-testid="stSidebar"] {
        background-color: #ffffff;
    }

    section[data-testid="stSidebar"] * {
        color: #111827;
    }

    textarea {
        background-color: #ffffff !important;
        color: #111827 !important;
    }

    input {
        background-color: #ffffff !important;
        color: #111827 !important;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# ============================================================
# AI AGENT
# ============================================================

def get_ai_agent():

    if not GROQ_API_KEY:

        raise ValueError(
            "GROQ_API_KEY is missing in your .env file."
        )

    return ChatGroq(
        model=MODEL,
        temperature=0,
        api_key=GROQ_API_KEY
    )


# ============================================================
# ANALYZE EVENT
# ============================================================

def analyze_event(event):

    llm = get_ai_agent()

    prompt = f"""
You are an Intelligent Communication Assistant.

Your job is to analyze an event and decide the best
communication method.

Available actions:

email
notification
both
none

Rules:

email:
Use email when the information is formal,
professional, or requires detailed information.

notification:
Use notification when the information is urgent
and should be short.

both:
Use both when the information is extremely important
and needs both email and notification.

none:
Use none when no communication is required.

IMPORTANT:

Return ONLY valid JSON.

Do not use markdown.

Do not use code fences.

Return exactly this structure:

{{
    "action": "email",
    "subject": "Short subject",
    "message": "Professional communication message",
    "reason": "Reason for selecting this action"
}}

EVENT:

{event}
"""

    response = llm.invoke(prompt)

    content = response.content

    # --------------------------------------------------------
    # HANDLE LIST RESPONSE
    # --------------------------------------------------------

    if isinstance(content, list):

        content = "".join(
            str(item.get("text", item))
            if isinstance(item, dict)
            else str(item)
            for item in content
        )

    content = str(content).strip()


    # --------------------------------------------------------
    # REMOVE CODE FENCES
    # --------------------------------------------------------

    content = content.replace(
        "```json",
        ""
    )

    content = content.replace(
        "```",
        ""
    )

    content = content.strip()


    # --------------------------------------------------------
    # FIND JSON OBJECT
    # --------------------------------------------------------

    start = content.find("{")
    end = content.rfind("}")

    if start != -1 and end != -1:

        content = content[
            start:end + 1
        ]


    # --------------------------------------------------------
    # PARSE JSON
    # --------------------------------------------------------

    try:

        result = json.loads(content)

    except Exception as error:

        raise ValueError(
            "AI returned invalid JSON.\n\n"
            f"Error: {error}\n\n"
            f"AI Response:\n{content}"
        )


    # --------------------------------------------------------
    # GET VALUES
    # --------------------------------------------------------

    action = str(
        result.get(
            "action",
            "none"
        )
    ).strip().lower()


    subject = str(
        result.get(
            "subject",
            "Important Notification"
        )
    ).strip()


    message = str(
        result.get(
            "message",
            ""
        )
    ).strip()


    reason = str(
        result.get(
            "reason",
            ""
        )
    ).strip()


    # --------------------------------------------------------
    # VALID ACTIONS
    # --------------------------------------------------------

    valid_actions = [
        "email",
        "notification",
        "both",
        "none"
    ]


    if action not in valid_actions:

        action = "none"


    return {
        "action": action,
        "subject": subject,
        "message": message,
        "reason": reason
    }


# ============================================================
# SEND EMAIL
# ============================================================

def send_email(
    recipient,
    subject,
    message
):

    if not SENDGRID_API_KEY:

        return (
            "ERROR: SENDGRID_API_KEY is missing."
        )


    if not SENDGRID_SENDER_EMAIL:

        return (
            "ERROR: SENDGRID_SENDER_EMAIL is missing."
        )


    if not recipient:

        return (
            "ERROR: Recipient email is missing."
        )


    try:

        from sendgrid import SendGridAPIClient

        from sendgrid.helpers.mail import Mail


        mail = Mail(
            from_email=SENDGRID_SENDER_EMAIL,
            to_emails=recipient,
            subject=subject,
            plain_text_content=message
        )


        client = SendGridAPIClient(
            SENDGRID_API_KEY
        )


        response = client.send(mail)


        if 200 <= response.status_code < 300:

            return (
                f"SUCCESS: Email sent to "
                f"{recipient}."
            )


        return (
            f"ERROR: SendGrid returned "
            f"status code {response.status_code}."
        )


    except Exception as error:

        return (
            f"ERROR: Email failed: {error}"
        )


# ============================================================
# PUSHOVER NOTIFICATION
# ============================================================

def send_notification(
    title,
    message
):

    if not PUSHOVER_APP_TOKEN:

        return (
            "ERROR: PUSHOVER_APP_TOKEN is missing."
        )


    if not PUSHOVER_USER_KEY:

        return (
            "ERROR: PUSHOVER_USER_KEY is missing."
        )


    try:

        response = requests.post(
            "https://api.pushover.net/1/messages.json",

            data={
                "token": PUSHOVER_APP_TOKEN,
                "user": PUSHOVER_USER_KEY,
                "title": title,
                "message": message
            },

            timeout=15
        )


        if response.status_code == 200:

            return (
                "SUCCESS: Pushover notification sent."
            )


        return (
            f"ERROR: Pushover returned "
            f"status code {response.status_code}."
        )


    except Exception as error:

        return (
            f"ERROR: Notification failed: {error}"
        )


# ============================================================
# EXECUTE ACTION
# ============================================================

def execute_action(
    decision,
    recipient_email,
    notification_title,
    real_send
):

    action = decision["action"]

    subject = decision["subject"]

    message = decision["message"]

    results = []


    # ========================================================
    # TEST MODE
    # ========================================================

    if not real_send:

        if action == "email":

            results.append(
                "TEST MODE: Email prepared. "
                "No real email was sent."
            )


        elif action == "notification":

            results.append(
                "TEST MODE: Notification prepared. "
                "No real notification was sent."
            )


        elif action == "both":

            results.append(
                "TEST MODE: Email and notification "
                "prepared. Nothing was sent."
            )


        else:

            results.append(
                "TEST MODE: No communication required."
            )


        return results


    # ========================================================
    # EMAIL
    # ========================================================

    if action == "email":

        result = send_email(
            recipient_email,
            subject,
            message
        )

        results.append(result)


    # ========================================================
    # NOTIFICATION
    # ========================================================

    elif action == "notification":

        title = (
            notification_title.strip()
            if notification_title.strip()
            else subject
        )

        result = send_notification(
            title,
            message
        )

        results.append(result)


    # ========================================================
    # BOTH
    # ========================================================

    elif action == "both":

        email_result = send_email(
            recipient_email,
            subject,
            message
        )


        notification_result = send_notification(
            notification_title
            if notification_title.strip()
            else subject,
            message
        )


        results.append(
            email_result
        )

        results.append(
            notification_result
        )


    # ========================================================
    # NONE
    # ========================================================

    else:

        results.append(
            "No communication action required."
        )


    return results


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.title(
        "📨 Communication Agent"
    )

    st.caption(
        "Intelligent Agentic AI System"
    )


    st.divider()


    st.subheader(
        "🔌 API Configuration"
    )


    # --------------------------------------------------------
    # GROQ
    # --------------------------------------------------------

    if GROQ_API_KEY:

        st.success(
            "🟢 Groq Connected"
        )

    else:

        st.error(
            "🔴 Groq Not Connected"
        )


    # --------------------------------------------------------
    # SENDGRID
    # --------------------------------------------------------

    if SENDGRID_API_KEY:

        st.success(
            "🟢 SendGrid Connected"
        )

    else:

        st.warning(
            "🟡 SendGrid Not Configured"
        )


    # --------------------------------------------------------
    # PUSHOVER
    # --------------------------------------------------------

    if (
        PUSHOVER_APP_TOKEN
        and PUSHOVER_USER_KEY
    ):

        st.success(
            "🟢 Pushover Connected"
        )

    else:

        st.warning(
            "🟡 Pushover Not Configured"
        )


    st.divider()


    st.subheader(
        "🤖 AI Model"
    )


    st.code(
        MODEL
    )


    st.divider()


    st.info(
        "API keys are loaded from your .env file."
    )


# ============================================================
# MAIN HEADER
# NO HTML
# ============================================================

st.title(
    "📨 Intelligent Communication Assistant"
)

st.subheader(
    "Agentic AI for Smart Email & Notification Communication"
)

st.write(
    "This AI agent analyzes an event, decides the best "
    "communication method, generates a professional "
    "message, and can execute Email or Push Notification tools."
)


# ============================================================
# SYSTEM STATUS
# ============================================================

st.divider()

st.header(
    "🔌 System Status"
)


col1, col2, col3 = st.columns(3)


with col1:

    if GROQ_API_KEY:

        st.success(
            "🤖 Groq AI\n\nConnected"
        )

    else:

        st.error(
            "🤖 Groq AI\n\nNot Connected"
        )


with col2:

    if SENDGRID_API_KEY:

        st.success(
            "📧 SendGrid\n\nConfigured"
        )

    else:

        st.warning(
            "📧 SendGrid\n\nNot Configured"
        )


with col3:

    if (
        PUSHOVER_APP_TOKEN
        and PUSHOVER_USER_KEY
    ):

        st.success(
            "🔔 Pushover\n\nConfigured"
        )

    else:

        st.warning(
            "🔔 Pushover\n\nNot Configured"
        )


# ============================================================
# EVENT INPUT
# ============================================================

st.divider()

st.header(
    "📋 Event / Request"
)


event = st.text_area(
    "Describe the situation",

    placeholder=(
        "Example:\n\n"
        "Tomorrow is the final deadline for submitting "
        "the AI assignment. Students who have not submitted "
        "their work should be reminded immediately."
    ),

    height=180
)


# ============================================================
# COMMUNICATION DETAILS
# ============================================================

st.header(
    "📨 Communication Details"
)


col1, col2 = st.columns(2)


with col1:

    recipient_email = st.text_input(
        "📧 Recipient Email",

        placeholder="example@gmail.com"
    )


with col2:

    notification_title = st.text_input(
        "🔔 Notification Title",

        value="Important Notification"
    )


# ============================================================
# EXECUTION MODE
# ============================================================

st.header(
    "🚀 Execution Mode"
)


real_send = st.checkbox(
    "Actually Send Email / Notification",

    value=False
)


if real_send:

    st.warning(
        "⚠️ Real Send Mode is ON. "
        "Actual communication may be sent."
    )

else:

    st.info(
        "🧪 Test Mode is ON. "
        "No real email or notification will be sent."
    )


# ============================================================
# ANALYZE & EXECUTE
# ============================================================

st.divider()


if st.button(
    "🤖 Analyze & Execute",

    type="primary",

    use_container_width=True
):

    # --------------------------------------------------------
    # EVENT VALIDATION
    # --------------------------------------------------------

    if not event.strip():

        st.error(
            "❌ Please enter an event first."
        )

        st.stop()


    # --------------------------------------------------------
    # GROQ VALIDATION
    # --------------------------------------------------------

    if not GROQ_API_KEY:

        st.error(
            "❌ GROQ_API_KEY is missing "
            "from your .env file."
        )

        st.stop()


    # --------------------------------------------------------
    # AI ANALYSIS
    # --------------------------------------------------------

    try:

        with st.spinner(
            "🤖 AI Agent is analyzing the event..."
        ):

            decision = analyze_event(
                event
            )


        st.success(
            "✅ Agent analysis completed successfully."
        )


        # ====================================================
        # AGENT DECISION
        # ====================================================

        st.header(
            "🧠 Agent Decision"
        )


        c1, c2, c3 = st.columns(3)


        with c1:

            st.metric(
                "Action",
                decision["action"].upper()
            )


        with c2:

            st.metric(
                "Mode",
                "REAL SEND"
                if real_send
                else "TEST MODE"
            )


        with c3:

            st.metric(
                "Status",
                "READY"
            )


        # ====================================================
        # REASON
        # ====================================================

        st.subheader(
            "💡 Decision Reason"
        )


        st.info(
            decision["reason"]
        )


        # ====================================================
        # SUBJECT
        # ====================================================

        st.subheader(
            "📌 Subject / Title"
        )


        st.write(
            decision["subject"]
        )


        # ====================================================
        # MESSAGE
        # ====================================================

        st.subheader(
            "📝 Generated Communication"
        )


        st.text_area(
            "AI Generated Message",

            value=decision["message"],

            height=180,

            disabled=True
        )


        # ====================================================
        # EXECUTION
        # ====================================================

        with st.spinner(
            "⚡ Executing communication tool..."
        ):

            results = execute_action(
                decision,
                recipient_email,
                notification_title,
                real_send
            )


        # ====================================================
        # TOOL RESULTS
        # ====================================================

        st.header(
            "⚡ Tool Execution Result"
        )


        for result in results:

            if result.startswith(
                "SUCCESS"
            ):

                st.success(
                    result
                )


            elif result.startswith(
                "ERROR"
            ):

                st.error(
                    result
                )


            else:

                st.info(
                    result
                )


        # ====================================================
        # SAVE LOG
        # ====================================================

        log = {

            "time":
                datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),

            "event":
                event,

            "action":
                decision["action"],

            "subject":
                decision["subject"],

            "message":
                decision["message"],

            "reason":
                decision["reason"],

            "mode":
                (
                    "REAL SEND"
                    if real_send
                    else "TEST MODE"
                ),

            "results":
                results
        }


        st.session_state.logs.append(
            log
        )


    # --------------------------------------------------------
    # ERROR HANDLING
    # --------------------------------------------------------

    except Exception as error:

        st.error(
            "❌ Something went wrong."
        )

        st.exception(error)


# ============================================================
# COMMUNICATION LOGS
# ============================================================

st.divider()

st.header(
    "📊 Communication Logs"
)


if not st.session_state.logs:

    st.info(
        "No communication activity yet."
    )


else:

    for log in reversed(
        st.session_state.logs
    ):

        with st.expander(
            f"{log['time']} | "
            f"{log['action'].upper()}"
        ):

            st.write(
                f"**Event:** {log['event']}"
            )


            st.write(
                f"**Action:** {log['action']}"
            )


            st.write(
                f"**Subject:** {log['subject']}"
            )


            st.write(
                f"**Reason:** {log['reason']}"
            )


            st.write(
                f"**Mode:** {log['mode']}"
            )


            st.write(
                "**Generated Message:**"
            )


            st.info(
                log["message"]
            )


            st.write(
                "**Execution Results:**"
            )


            for result in log["results"]:

                st.write(
                    f"• {result}"
                )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "📨 Intelligent Communication Assistant | "
    "Agentic AI • Groq • SendGrid • Pushover • Streamlit"
)

