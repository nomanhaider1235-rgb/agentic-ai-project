import streamlit as st

from agent import agent


# ==========================================
# PAGE CONFIG
# ==========================================

st.set_page_config(
    page_title="Project O1 - ReAct Agent",
    page_icon="🤖"
)


# ==========================================
# TITLE
# ==========================================

st.title("🤖 Project O1 — ReAct AI Agent")

st.write(
    "Ask a question and the AI agent will decide "
    "whether it needs to use a tool."
)


# ==========================================
# USER INPUT
# ==========================================

question = st.text_input(
    "Enter your question:",
    placeholder="Example: What is 25 × 4?"
)


# ==========================================
# RUN AGENT
# ==========================================

if st.button("🚀 Ask Agent", use_container_width=True):

    if not question.strip():

        st.warning("Please enter a question.")

    else:

        with st.spinner("🤖 Agent is thinking..."):

            try:

                result = agent.invoke(
                    {
                        "messages": [
                            {
                                "role": "user",
                                "content": question.strip()
                            }
                        ]
                    }
                )

                messages = result.get(
                    "messages",
                    []
                )

                if messages:

                    final_message = messages[-1]

                    if hasattr(
                        final_message,
                        "content"
                    ):

                        answer = final_message.content

                    else:

                        answer = str(
                            final_message
                        )

                    st.success("✅ Agent Response")

                    st.write(answer)

                else:

                    st.warning(
                        "The agent did not return a response."
                    )

            except Exception as e:

                st.error(
                    f"❌ Agent Error: {e}"
                )