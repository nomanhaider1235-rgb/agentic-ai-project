from langchain_ollama import ChatOllama
from langchain.agents import create_agent

from tools import TOOLS


# ==========================================
# OLLAMA MODEL
# ==========================================

llm = ChatOllama(
    model="qwen3:4b",
    temperature=0
)


# ==========================================
# REACT AGENT
# ==========================================

agent = create_agent(
    model=llm,
    tools=TOOLS,
    system_prompt=(
        "You are a helpful AI assistant. "
        "Use the available tools whenever they are "
        "needed to answer the user's question. "
        "For calculations, use the calculator tool. "
        "For weather questions, use the weather tool. "
        "Give a clear and concise final answer."
    )
)