from langchain_core.tools import tool


@tool
def calculator(expression: str) -> str:
    """Calculate a basic mathematical expression."""

    try:
        result = eval(
            expression,
            {"__builtins__": {}},
            {}
        )

        return str(result)

    except Exception:
        return "Unable to calculate the expression."


@tool
def get_weather(city: str) -> str:
    """Return demo weather information for a city."""

    weather_data = {
        "islamabad": "Islamabad: 28°C, partly cloudy",
        "lahore": "Lahore: 32°C, sunny",
        "karachi": "Karachi: 30°C, humid",
        "multan": "Multan: 34°C, sunny",
        "faisalabad": "Faisalabad: 31°C, partly cloudy",
    }

    city_key = city.strip().lower()

    return weather_data.get(
        city_key,
        f"{city}: Weather information is not available in the demo database."
    )


TOOLS = [
    calculator,
    get_weather
]