from typing import TypedDict, Literal

from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, START, END


# =========================================================
# LLM
# =========================================================

llm = ChatOllama(
    model="qwen3:4b",
    temperature=0
)


# =========================================================
# TOOLS
# =========================================================

@tool
def calculator(expression: str) -> str:
    """
    Calculate a basic mathematical expression.
    """

    allowed = set(
        "0123456789+-*/(). "
    )

    if not all(
        character in allowed
        for character in expression
    ):
        return "Invalid mathematical expression."

    try:
        result = eval(
            expression,
            {"__builtins__": {}},
            {}
        )

        return str(result)

    except Exception:
        return "Could not calculate the expression."


# =========================================================
# STATE
# =========================================================

class AgentState(TypedDict):

    question: str

    task_type: str

    researcher_result: str

    calculator_result: str

    final_answer: str


# =========================================================
# MANAGER AGENT
# =========================================================

def manager_agent(state: AgentState):

    question = state["question"]

    prompt = f"""
You are the Manager Agent.

Analyze the user's question and decide which
specialized agent should solve it.

User Question:
{question}

Choose exactly one:

researcher
calculator

Rules:

Use researcher for:
- factual questions
- explanations
- general knowledge
- comparisons
- research

Use calculator for:
- mathematical calculations
- arithmetic
- numerical problems

Return ONLY:
researcher

or:

calculator
"""

    response = llm.invoke(prompt)

    decision = response.content.strip().lower()

    if "calculator" in decision:

        task_type = "calculator"

    else:

        task_type = "researcher"

    return {
        "task_type": task_type
    }


# =========================================================
# ROUTER
# =========================================================

def route_manager(
    state: AgentState
) -> Literal["researcher", "calculator"]:

    if state["task_type"] == "calculator":

        return "calculator"

    return "researcher"


# =========================================================
# RESEARCHER AGENT
# =========================================================

def researcher_agent(state: AgentState):

    question = state["question"]

    prompt = f"""
You are the Researcher Agent.

Solve the user's question using your
general knowledge.

User Question:
{question}

Give a clear and useful explanation.

Do not perform complicated calculations.
"""

    response = llm.invoke(prompt)

    return {
        "researcher_result": response.content
    }


# =========================================================
# CALCULATOR AGENT
# =========================================================

def calculator_agent(state: AgentState):

    question = state["question"]

    prompt = f"""
You are the Calculator Agent.

Solve the numerical or mathematical
problem in the user's question.

User Question:
{question}

Use the calculator tool when a calculation
is required.

Show the important calculation steps and
give the final result.
"""

    calculator_llm = llm.bind_tools(
        [calculator]
    )

    response = calculator_llm.invoke(prompt)

    # -----------------------------------------------------
    # TOOL CALL
    # -----------------------------------------------------

    if response.tool_calls:

        tool_call = response.tool_calls[0]

        expression = tool_call["args"].get(
            "expression",
            ""
        )

        calculation = calculator.invoke(
            {
                "expression": expression
            }
        )

        final_prompt = f"""
You are the Calculator Agent.

User Question:
{question}

Calculator result:
{calculation}

Provide the final answer clearly.
"""

        final_response = llm.invoke(
            final_prompt
        )

        return {
            "calculator_result":
                final_response.content
        }

    # -----------------------------------------------------
    # NO TOOL CALL
    # -----------------------------------------------------

    return {
        "calculator_result":
            response.content
    }


# =========================================================
# FINAL MANAGER
# =========================================================

def final_manager(state: AgentState):

    question = state["question"]

    researcher_result = state.get(
        "researcher_result",
        ""
    )

    calculator_result = state.get(
        "calculator_result",
        ""
    )

    prompt = f"""
You are the Final Manager Agent.

Prepare the final answer for the user.

User Question:
{question}

Researcher Result:
{researcher_result}

Calculator Result:
{calculator_result}

Instructions:

1. Use the relevant specialist result.
2. Ignore empty results.
3. Give a clear and useful final answer.
4. Do not mention internal agents.
5. Do not mention the workflow.
6. Do not say that you are a manager.
"""

    response = llm.invoke(prompt)

    return {
        "final_answer": response.content
    }


# =========================================================
# BUILD LANGGRAPH
# =========================================================

workflow = StateGraph(
    AgentState
)


# =========================================================
# ADD NODES
# =========================================================

workflow.add_node(
    "manager",
    manager_agent
)

workflow.add_node(
    "researcher",
    researcher_agent
)

workflow.add_node(
    "calculator",
    calculator_agent
)

workflow.add_node(
    "final_manager",
    final_manager
)


# =========================================================
# ADD EDGES
# =========================================================

workflow.add_edge(
    START,
    "manager"
)

workflow.add_conditional_edges(
    "manager",
    route_manager,
    {
        "researcher": "researcher",
        "calculator": "calculator"
    }
)

workflow.add_edge(
    "researcher",
    "final_manager"
)

workflow.add_edge(
    "calculator",
    "final_manager"
)

workflow.add_edge(
    "final_manager",
    END
)


# =========================================================
# COMPILE
# =========================================================

app = workflow.compile()


# =========================================================
# TEST
# =========================================================

if __name__ == "__main__":

    print(
        "\n===================================="
    )

    print(
        "MULTI-AGENT PROBLEM SOLVING SYSTEM"
    )

    print(
        "====================================\n"
    )

    question = input(
        "Enter your question: "
    )

    result = app.invoke(
        {
            "question": question,
            "task_type": "",
            "researcher_result": "",
            "calculator_result": "",
            "final_answer": ""
        }
    )

    print(
        "\n===================================="
    )

    print(
        "FINAL ANSWER"
    )

    print(
        "===================================="
    )

    print(
        result["final_answer"]
    )