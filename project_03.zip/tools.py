# ==========================================
# PROJECT 3 — TOOLS
# ==========================================


def research_tool(topic):
    """
    Simple research tool for the Researcher Agent.
    """

    return f"""
Research topic: {topic}

This topic requires factual research and
analysis. The Researcher Agent should provide
a clear explanation based on the available
knowledge.
"""


def calculator_tool(expression):
    """
    Calculate a mathematical expression.
    """

    try:

        allowed_characters = (
            "0123456789+-*/(). "
        )

        if not all(
            character in allowed_characters
            for character in expression
        ):

            return "Invalid mathematical expression."

        result = eval(
            expression,
            {"__builtins__": {}},
            {}
        )

        return str(result)

    except Exception:

        return "Unable to calculate expression."