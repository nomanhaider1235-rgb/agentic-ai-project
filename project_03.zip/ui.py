import streamlit as st

from agent import app


# ==========================================
# PAGE CONFIG
# ==========================================

st.set_page_config(
    page_title="Multi-Agent Problem Solving System",
    page_icon="🤖",
    layout="wide"
)


# ==========================================
# HEADER
# ==========================================

st.title(
    "🤖 Multi-Agent Problem Solving System"
)

st.write(
    "AI Research & Analysis Team powered by "
    "LangGraph, specialized agents and tool calling."
)

st.divider()


# ==========================================
# USER QUESTION
# ==========================================

st.subheader("📝 Ask Your Question")

question = st.text_area(
    "Enter your problem:",
    placeholder=(
        "Example: What is artificial intelligence?\n"
        "Or: Calculate 125 * 24"
    ),
    height=150
)


# ==========================================
# SOLVE
# ==========================================

if st.button(
    "🚀 Solve Problem",
    use_container_width=True
):

    if not question.strip():

        st.warning(
            "Please enter a question first."
        )

    else:

        with st.spinner(
            "🤖 Multi-Agent Team is solving your problem..."
        ):

            result = app.invoke(
                {
                    "question": question.strip(),
                    "task_type": "",
                    "researcher_result": "",
                    "calculator_result": "",
                    "final_answer": ""
                }
            )


        st.success(
            "✅ Problem solved successfully!"
        )


        # ======================================
        # AGENT ROUTING
        # ======================================

        st.subheader(
            "🔀 Agent Used"
        )

        task_type = result.get(
            "task_type",
            ""
        )

        if task_type == "researcher":

            st.info(
                "🔎 Researcher Agent"
            )

        elif task_type == "calculator":

            st.info(
                "🧮 Calculator Agent"
            )


        # ======================================
        # FINAL ANSWER
        # ======================================

        st.subheader(
            "💡 Final Answer"
        )

        st.write(
            result.get(
                "final_answer",
                "No answer generated."
            )
        )


# ==========================================
# WORKFLOW
# ==========================================

st.divider()

st.subheader(
    "🔄 Multi-Agent Workflow"
)

st.write(
    "👨‍💼 Manager → "
    "🔎 Researcher / 🧮 Calculator → "
    "👨‍💼 Final Manager → "
    "💡 Final Answer"
)