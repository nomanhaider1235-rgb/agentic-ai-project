
import os
import re
import sqlite3
from datetime import datetime

import streamlit as st
from dotenv import load_dotenv


# ============================================================
# CONFIGURATION
# ============================================================

load_dotenv()

APP_TITLE = "AI Customer Support Agent"
DATABASE = "customer_support.db"
MODEL = "llama-3.3-70b-versatile"

GROQ_API_KEY = os.getenv("GROQ_API_KEY")


# ============================================================
# GROQ CLIENT
# ============================================================

client = None

if GROQ_API_KEY:
    try:
        from groq import Groq

        client = Groq(api_key=GROQ_API_KEY)

    except Exception:
        client = None


# ============================================================
# STREAMLIT CONFIG
# ============================================================

st.set_page_config(
    page_title=APP_TITLE,
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)


# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown(
    """
    <style>

    .main-title {
        font-size: 42px;
        font-weight: 700;
        text-align: center;
        margin-bottom: 5px;
    }

    .subtitle {
        text-align: center;
        font-size: 18px;
        margin-bottom: 25px;
    }

    .status-box {
        padding: 15px;
        border-radius: 12px;
        margin-bottom: 15px;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# ============================================================
# DATABASE INITIALIZATION
# ============================================================

def initialize_database():
    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT,
            question TEXT,
            response TEXT,
            sentiment TEXT,
            priority TEXT,
            created_at TEXT
        )
        """
    )

    connection.commit()
    connection.close()


initialize_database()


# ============================================================
# SAVE CHAT
# ============================================================

def save_chat(
    customer_name,
    question,
    response,
    sentiment,
    priority
):
    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute(
        """
        INSERT INTO chats
        (
            customer_name,
            question,
            response,
            sentiment,
            priority,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            customer_name,
            question,
            response,
            sentiment,
            priority,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
    )

    connection.commit()
    connection.close()


# ============================================================
# GET CHAT HISTORY
# ============================================================

def get_chats():

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT
            customer_name,
            question,
            response,
            sentiment,
            priority,
            created_at
        FROM chats
        ORDER BY id DESC
        """
    )

    chats = cursor.fetchall()

    connection.close()

    return chats


# ============================================================
# AI CUSTOMER SUPPORT
# ============================================================

def get_ai_response(
    customer_name,
    question,
    conversation
):

    if client is None:

        return (
            "❌ Groq API is not connected.\n\n"
            "Please add GROQ_API_KEY to your .env file.",
            "Neutral",
            "Medium"
        )

    # ========================================================
    # CONVERSATION HISTORY
    # ========================================================

    history = ""

    for message in conversation[-10:]:

        history += (
            f"{message['role']}: "
            f"{message['content']}\n"
        )

    # ========================================================
    # AI PROMPT
    # ========================================================

    prompt = f"""
You are a professional AI customer support agent.

Customer Name:
{customer_name}

Conversation History:
{history}

Current Customer Question:
{question}

Your responsibilities:

1. Understand the customer's problem.
2. Give a helpful and professional response.
3. Identify the customer's sentiment.
4. Identify the priority of the issue.

Use exactly this format:

RESPONSE:
Write the customer support response here.

SENTIMENT:
Positive

PRIORITY:
Medium

Sentiment must be exactly one of:
Positive
Neutral
Negative

Priority must be exactly one of:
Low
Medium
High

Be polite, professional and helpful.
Do not add extra sections.
"""

    # ========================================================
    # API CALL
    # ========================================================

    try:

        result = client.chat.completions.create(
            model=MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a professional "
                        "customer support AI agent."
                    )
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.4,
            max_tokens=1000
        )

        raw_response = (
            result.choices[0]
            .message
            .content
        )

        if not raw_response:
            return (
                "❌ AI ne koi response generate nahi kiya.",
                "Neutral",
                "Medium"
            )

        # ====================================================
        # EXTRACT RESPONSE
        # ====================================================

        response_match = re.search(
            r"RESPONSE:\s*(.*?)(?=\n\s*SENTIMENT:)",
            raw_response,
            re.DOTALL | re.IGNORECASE
        )

        # ====================================================
        # EXTRACT SENTIMENT
        # ====================================================

        sentiment_match = re.search(
            r"SENTIMENT:\s*(.*?)(?=\n\s*PRIORITY:)",
            raw_response,
            re.DOTALL | re.IGNORECASE
        )

        # ====================================================
        # EXTRACT PRIORITY
        # ====================================================

        priority_match = re.search(
            r"PRIORITY:\s*(.*)",
            raw_response,
            re.DOTALL | re.IGNORECASE
        )

        # ====================================================
        # RESPONSE VALUE
        # ====================================================

        if response_match:

            response = (
                response_match
                .group(1)
                .strip()
            )

        else:

            response = raw_response.strip()

        # ====================================================
        # SENTIMENT VALUE
        # ====================================================

        if sentiment_match:

            sentiment = (
                sentiment_match
                .group(1)
                .strip()
                .splitlines()[0]
                .strip()
            )

        else:

            sentiment = "Neutral"

        # ====================================================
        # PRIORITY VALUE
        # ====================================================

        if priority_match:

            priority = (
                priority_match
                .group(1)
                .strip()
                .splitlines()[0]
                .strip()
            )

        else:

            priority = "Medium"

        # ====================================================
        # CLEAN SENTIMENT
        # ====================================================

        sentiment_lower = sentiment.lower()

        if sentiment_lower == "positive":

            sentiment = "Positive"

        elif sentiment_lower == "negative":

            sentiment = "Negative"

        else:

            sentiment = "Neutral"

        # ====================================================
        # CLEAN PRIORITY
        # ====================================================

        priority_lower = priority.lower()

        if priority_lower == "high":

            priority = "High"

        elif priority_lower == "low":

            priority = "Low"

        else:

            priority = "Medium"

        return (
            response,
            sentiment,
            priority
        )

    except Exception as error:

        return (
            "❌ AI response generate nahi ho saka.\n\n"
            f"Error: {error}",
            "Neutral",
            "High"
        )


# ============================================================
# SESSION STATE
# ============================================================

if "messages" not in st.session_state:

    st.session_state.messages = []


if "customer_name" not in st.session_state:

    st.session_state.customer_name = ""


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.title("🤖 AI Support Agent")

    st.write(
        "Intelligent Customer Support System"
    )

    st.divider()

    page = st.radio(
        "Navigation",
        [
            "🏠 Dashboard",
            "💬 Customer Support",
            "📊 Chat History"
        ]
    )

    st.divider()

    if client:

        st.success(
            "🟢 Groq API Connected"
        )

    else:

        st.error(
            "🔴 Groq API Not Connected"
        )

        st.info(
            "Add GROQ_API_KEY in your .env file."
        )

    st.divider()

    if st.button(
        "🗑️ Clear Current Chat",
        use_container_width=True
    ):

        st.session_state.messages = []

        st.rerun()

    st.divider()

    st.caption(
        "Powered by Groq + Streamlit + SQLite"
    )


# ============================================================
# DASHBOARD
# ============================================================

if page == "🏠 Dashboard":

    st.markdown(
        '<div class="main-title">🤖 AI Customer Support Agent</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">Smart Customer Service Assistant</div>',
        unsafe_allow_html=True
    )

    st.info(
        "💡 Ask a customer support question "
        "and let AI handle it."
    )

    st.divider()

    chats = get_chats()

    total_chats = len(chats)

    high_priority = sum(
        1
        for chat in chats
        if chat[4] == "High"
    )

    negative_count = sum(
        1
        for chat in chats
        if chat[3] == "Negative"
    )

    # ========================================================
    # METRICS
    # ========================================================

    col1, col2, col3, col4 = st.columns(4)

    with col1:

        st.metric(
            "💬 Total Chats",
            total_chats
        )

    with col2:

        st.metric(
            "🚨 High Priority",
            high_priority
        )

    with col3:

        st.metric(
            "😟 Negative",
            negative_count
        )

    with col4:

        if client:

            st.metric(
                "🤖 AI Status",
                "Online"
            )

        else:

            st.metric(
                "🤖 AI Status",
                "Offline"
            )

    st.divider()

    st.header(
        "🚀 How This Agent Works"
    )

    col1, col2, col3 = st.columns(3)

    with col1:

        st.info(
            "1️⃣ Understand\n\n"
            "AI reads the customer's question."
        )

    with col2:

        st.warning(
            "2️⃣ Analyze\n\n"
            "AI identifies sentiment and priority."
        )

    with col3:

        st.success(
            "3️⃣ Respond\n\n"
            "AI creates a professional response."
        )


# ============================================================
# CUSTOMER SUPPORT
# ============================================================

elif page == "💬 Customer Support":

    st.title(
        "💬 Customer Support"
    )

    st.write(
        "Chat with your AI customer support agent."
    )

    st.divider()

    # ========================================================
    # CUSTOMER NAME
    # ========================================================

    customer_name = st.text_input(
        "👤 Customer Name",
        value=st.session_state.customer_name,
        placeholder="Enter customer name"
    )

    st.session_state.customer_name = customer_name

    # ========================================================
    # DISPLAY MESSAGES
    # ========================================================

    for message in st.session_state.messages:

        with st.chat_message(
            message["role"]
        ):

            st.write(
                message["content"]
            )

            if (
                message["role"] == "assistant"
                and "sentiment" in message
            ):

                col1, col2 = st.columns(2)

                with col1:

                    sentiment = message["sentiment"]

                    if sentiment == "Positive":

                        st.success(
                            f"😊 Sentiment: {sentiment}"
                        )

                    elif sentiment == "Negative":

                        st.error(
                            f"😟 Sentiment: {sentiment}"
                        )

                    else:

                        st.info(
                            f"😐 Sentiment: {sentiment}"
                        )

                with col2:

                    priority = message["priority"]

                    if priority == "High":

                        st.error(
                            f"🚨 Priority: {priority}"
                        )

                    elif priority == "Medium":

                        st.warning(
                            f"⚠️ Priority: {priority}"
                        )

                    else:

                        st.success(
                            f"🟢 Priority: {priority}"
                        )

    # ========================================================
    # CHAT INPUT
    # ========================================================

    user_question = st.chat_input(
        "Type your customer question..."
    )

    if user_question:

        if not customer_name.strip():

            st.warning(
                "⚠️ Please enter customer name first."
            )

        elif client is None:

            st.error(
                "❌ Groq API is not connected. "
                "Please check your .env file."
            )

        else:

            # =================================================
            # ADD USER MESSAGE
            # =================================================

            st.session_state.messages.append(
                {
                    "role": "user",
                    "content": user_question
                }
            )

            with st.chat_message("user"):

                st.write(
                    user_question
                )

            # =================================================
            # AI RESPONSE
            # =================================================

            with st.chat_message("assistant"):

                with st.spinner(
                    "🤖 AI is thinking..."
                ):

                    response, sentiment, priority = (
                        get_ai_response(
                            customer_name,
                            user_question,
                            st.session_state.messages
                        )
                    )

                st.write(
                    response
                )

                col1, col2 = st.columns(2)

                # =================================================
                # SENTIMENT
                # =================================================

                with col1:

                    if sentiment == "Positive":

                        st.success(
                            f"😊 Sentiment: {sentiment}"
                        )

                    elif sentiment == "Negative":

                        st.error(
                            f"😟 Sentiment: {sentiment}"
                        )

                    else:

                        st.info(
                            f"😐 Sentiment: {sentiment}"
                        )

                # =================================================
                # PRIORITY
                # =================================================

                with col2:

                    if priority == "High":

                        st.error(
                            f"🚨 Priority: {priority}"
                        )

                    elif priority == "Medium":

                        st.warning(
                            f"⚠️ Priority: {priority}"
                        )

                    else:

                        st.success(
                            f"🟢 Priority: {priority}"
                        )

            # =================================================
            # SAVE ASSISTANT MESSAGE
            # =================================================

            st.session_state.messages.append(
                {
                    "role": "assistant",
                    "content": response,
                    "sentiment": sentiment,
                    "priority": priority
                }
            )

            # =================================================
            # SAVE TO DATABASE
            # =================================================

            try:

                save_chat(
                    customer_name,
                    user_question,
                    response,
                    sentiment,
                    priority
                )

                st.success(
                    "✅ Conversation saved."
                )

            except Exception as error:

                st.error(
                    f"Database error: {error}"
                )


# ============================================================
# CHAT HISTORY
# ============================================================

elif page == "📊 Chat History":

    st.title(
        "📊 Chat History"
    )

    chats = get_chats()

    if not chats:

        st.info(
            "📭 No conversations found yet."
        )

    else:

        st.success(
            f"✅ {len(chats)} conversation(s) found."
        )

        for chat in chats:

            (
                customer_name,
                question,
                response,
                sentiment,
                priority,
                created_at
            ) = chat

            with st.expander(
                f"👤 {customer_name} | "
                f"{sentiment} | "
                f"{priority}"
            ):

                st.write(
                    f"**👤 Customer:** {customer_name}"
                )

                st.write(
                    f"**❓ Question:** {question}"
                )

                st.write(
                    "**🤖 AI Response:**"
                )

                st.write(
                    response
                )

                col1, col2 = st.columns(2)

                with col1:

                    if sentiment == "Positive":

                        st.success(
                            f"😊 **Sentiment:** {sentiment}"
                        )

                    elif sentiment == "Negative":

                        st.error(
                            f"😟 **Sentiment:** {sentiment}"
                        )

                    else:

                        st.info(
                            f"😐 **Sentiment:** {sentiment}"
                        )

                with col2:

                    if priority == "High":

                        st.error(
                            f"🚨 **Priority:** {priority}"
                        )

                    elif priority == "Medium":

                        st.warning(
                            f"⚠️ **Priority:** {priority}"
                        )

                    else:

                        st.success(
                            f"🟢 **Priority:** {priority}"
                        )

                st.caption(
                    f"📅 {created_at}"
                )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "🤖 AI Customer Support Agent | "
    "Groq + Streamlit + SQLite"
)

