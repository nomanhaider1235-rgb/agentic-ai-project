import streamlit as st

from agent import app


# ==========================================
# PAGE CONFIG
# ==========================================

st.set_page_config(
    page_title="Project 2 - Knowledge Agent",
    page_icon="🧠",
    layout="wide"
)


# ==========================================
# HEADER
# ==========================================

st.title("🧠 Project 2 — Knowledge-Based Decision Agent")

st.write(
    "Ask questions about the company's products. "
    "The agent retrieves information from a private "
    "knowledge base before generating an answer."
)

st.divider()


# ==========================================
# USER QUESTION
# ==========================================

question = st.text_area(
    "💬 Enter your question",
    placeholder=(
        "Example: Which HP laptop is available "
        "for Rs. 150,000?"
    ),
    height=120
)


# ==========================================
# ASK AGENT
# ==========================================

if st.button(
    "🤖 Ask Knowledge Agent",
    use_container_width=True
):

    if not question.strip():

        st.warning(
            "Please enter a question."
        )

    else:

        with st.spinner(
            "🔎 Searching private knowledge base..."
        ):

            try:

                result = app.invoke(
                    {
                        "question": question.strip(),
                        "context": "",
                        "answer": ""
                    }
                )

                st.success(
                    "✅ Knowledge Agent Response"
                )

                st.write(
                    result["answer"]
                )

                # --------------------------------
                # Retrieved Context
                # --------------------------------

                with st.expander(
                    "📚 View Retrieved Knowledge"
                ):

                    st.write(
                        result["context"]
                    )

            except Exception as e:

                st.error(
                    f"❌ Agent Error: {e}"
                )


# ==========================================
# FOOTER
# ==========================================

st.divider()

st.caption(
    "Project 2 | Agentic RAG + Chroma + LangGraph "
    "| Powered by Ollama"
)