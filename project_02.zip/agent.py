from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, START, END
from typing import TypedDict

from knowledge_base import search_knowledge_base


# ==========================================
# STATE
# ==========================================

class AgentState(TypedDict):
    question: str
    context: str
    answer: str


# ==========================================
# OLLAMA MODEL
# ==========================================

llm = ChatOllama(
    model="qwen3:4b",
    temperature=0
)


# ==========================================
# RETRIEVAL NODE
# ==========================================

def retrieve_knowledge(state: AgentState):

    question = state["question"]

    documents = search_knowledge_base(
        question,
        k=3
    )

    context = "\n\n".join(
        document.page_content
        for document in documents
    )

    return {
        "context": context
    }


# ==========================================
# ANSWER NODE
# ==========================================

def generate_answer(state: AgentState):

    question = state["question"]
    context = state["context"]

    prompt = f"""
You are a Knowledge-Based Decision Agent.

Answer the user's question using ONLY the
information provided in the company knowledge base.

If the answer is not available in the knowledge
base, clearly say that the information is not
available in the company knowledge base.

Do not invent product specifications or prices.

Company Knowledge Base:
{context}

User Question:
{question}

Give a clear and useful answer.
"""

    response = llm.invoke(prompt)

    return {
        "answer": response.content
    }


# ==========================================
# LANGGRAPH
# ==========================================

graph = StateGraph(AgentState)

graph.add_node(
    "retrieve",
    retrieve_knowledge
)

graph.add_node(
    "answer",
    generate_answer
)

graph.add_edge(
    START,
    "retrieve"
)

graph.add_edge(
    "retrieve",
    "answer"
)

graph.add_edge(
    "answer",
    END
)


# ==========================================
# COMPILE
# ==========================================

app = graph.compile()