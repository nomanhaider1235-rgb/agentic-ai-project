from pathlib import Path

from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma


# ==========================================
# PATHS
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

DATA_FILE = BASE_DIR / "data" / "company_knowledge.txt"

CHROMA_DIR = BASE_DIR / "chroma_db"


# ==========================================
# CREATE KNOWLEDGE BASE
# ==========================================

def create_knowledge_base():

    # Load private company document
    loader = TextLoader(
        str(DATA_FILE),
        encoding="utf-8"
    )

    documents = loader.load()

    # Create embeddings
    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    # Create Chroma vector database
    vectorstore = Chroma.from_documents(
        documents=documents,
        embedding=embeddings,
        persist_directory=str(CHROMA_DIR)
    )

    return vectorstore


# ==========================================
# SEARCH KNOWLEDGE BASE
# ==========================================

def search_knowledge_base(
    question,
    k=3
):

    vectorstore = create_knowledge_base()

    results = vectorstore.similarity_search(
        question,
        k=k
    )

    return results